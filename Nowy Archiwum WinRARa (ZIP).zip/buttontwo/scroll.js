
    gsap.registerPlugin(ScrollTrigger); //-scroll

    //-animate Text
    gsap.from(".textt", {
        opacity: 0,
        x: -100,
        duration: 1,
        scrollTrigger: {
            trigger: ".textt",
            start: "top 80%",
            toggleActions: "play none none reverse"
        }
    });

    //-animate about
    gsap.from(".about", {
        opacity: 0,
        y: 50,
        duration: 1.2,
        scrollTrigger: {
            trigger: ".about",
            start: "top 75%",
            toggleActions: "play none none reverse"
        }
    });

    //-animate functions
    gsap.from(".functions", {
        opacity: 0,
        x: -100,
        duration: 1.2,
        scrollTrigger: {
            trigger: ".functions",
            start: "top 75%",
            toggleActions: "play none none reverse"
        }
    });

   //-animate underlogo
   gsap.from(".underlogo", {
    opacity: 0,
    x: 100,
    duration: 1.2,
    scrollTrigger: {
        trigger: ".underlogo",
        start: "top 75%",
        toggleActions: "play none none reverse"
    }
    });

    //-Animate Socials
    gsap.from(".socials", {
        opacity: 0,
        y: 50,
        duration: 1.2,
        scrollTrigger: {
            trigger: ".socials",
            start: "top 75%",
            toggleActions: "play none none reverse"
        }
    });

    //-Animate hidde 4
    gsap.from(".hide-bg4", {
        opacity: 0,
        y: 50,
        duration: 1.2,
        scrollTrigger: {
            trigger: ".hide-bg4",
            start: "top 75%",
            toggleActions: "play none none reverse"
        }
    });


    //-Animate Main Heading
    gsap.from(".hoe", {
        opacity: 0,
        scale: 0.9,
        duration: 1.5,
        scrollTrigger: {
            trigger: ".hoe",
            start: "top 85%",
            toggleActions: "play none none reverse"
        }
    });

    //-Animate Box Section
    gsap.from(".box", {
        opacity: 0,
        y: 100,
        duration: 1.5,
        scrollTrigger: {
            trigger: ".box",
            start: "top 90%",
            toggleActions: "play none none reverse"
        }
    });

