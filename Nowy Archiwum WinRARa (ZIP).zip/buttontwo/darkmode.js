document.addEventListener("DOMContentLoaded", () => {
    const themeSwitch = document.getElementById("theme-switch");
    const currentTheme = localStorage.getItem("theme");
  
    if (currentTheme === "darkmode") {
      document.documentElement.classList.add("darkmode");
    }
  
    themeSwitch.addEventListener("click", () => {
      document.documentElement.classList.toggle("darkmode");
  
      const newTheme = document.documentElement.classList.contains("darkmode") ? "darkmode" : "light";
      localStorage.setItem("theme", newTheme);
    });
  });
  